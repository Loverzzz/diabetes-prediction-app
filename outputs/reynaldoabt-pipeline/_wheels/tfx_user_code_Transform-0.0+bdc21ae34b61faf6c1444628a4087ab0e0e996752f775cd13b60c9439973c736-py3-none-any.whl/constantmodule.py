
NUMERICAL_FEATURES = ['age', 'bmi', 'HbA1c_level', 'blood_glucose_level']

CATEGORICAL_STRING_FEATURES = [
    'gender',
    'smoking_history'
]

BINARY_FEATURES = [
    'hypertension',
    'heart_disease'
]

# Number of vocabulary terms used for encoding categorical features.
VOCAB_SIZE = 100

# Count of out-of-vocab buckets in which unrecognized categorical are hashed.
OOV_SIZE = 10

# Keys
LABEL_KEY = 'diabetes'

def t_name(key):
  return key + '_xf'
