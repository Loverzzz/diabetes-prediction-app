# app.py
import os
import json
import numpy as np
import tensorflow as tf
from flask import Flask, request, jsonify
from prometheus_flask_exporter import PrometheusMetrics
import time

# Inisialisasi Flask app
app = Flask(__name__)

# Inisialisasi Prometheus metrics
metrics = PrometheusMetrics(app)

# Tambahkan custom metrics
model_predict_time = metrics.summary('model_prediction_seconds', 'Time spent on prediction')
prediction_counter = metrics.counter('prediction_total', 'Number of predictions', 
                                    labels={'status': lambda: request.endpoint})

# Load model
MODEL_DIR = os.getenv('MODEL_DIR', 'serving_model')
# Cari versi model terbaru (folder dengan nama timestamp)
model_versions = [d for d in os.listdir(MODEL_DIR) if os.path.isdir(os.path.join(MODEL_DIR, d))]
if model_versions:
    latest_version = sorted(model_versions)[-1]  # Ambil versi terbaru berdasarkan timestamp
    MODEL_PATH = os.path.join(MODEL_DIR, latest_version)
    print(f"Loading model from: {MODEL_PATH}")
    model = tf.saved_model.load(MODEL_PATH)
    predict_fn = model.signatures['serving_default']
else:
    raise ValueError(f"No model versions found in {MODEL_DIR}")

# Feature names setelah transformasi
FEATURE_NAMES = [
    'age_xf', 'hypertension_xf', 'heart_disease_xf', 'bmi_xf', 
    'HbA1c_level_xf', 'blood_glucose_level_xf', 'gender_xf', 'smoking_history_xf'
]

@app.route('/')
def home():
    return "Diabetes Prediction API is running. Use /predict endpoint for predictions."

@app.route('/health')
def health():
    return jsonify({"status": "healthy"})

@app.route('/predict', methods=['POST'])
@prediction_counter
@model_predict_time
def predict():
    try:
        # Get input data
        data = request.json
        
        # Prepare input tensors (asumsi data sudah ditransformasi)
        input_dict = {}
        for feature in FEATURE_NAMES:
            if feature in data:
                input_dict[feature] = tf.convert_to_tensor([data[feature]], dtype=tf.float32)
            else:
                return jsonify({"error": f"Missing feature: {feature}"}), 400
        
        # Make prediction
        start_time = time.time()
        predictions = predict_fn(**input_dict)
        prediction_time = time.time() - start_time
        
        # Get prediction value
        prediction_value = predictions['output_0'].numpy()[0][0]
        
        # Return prediction result
        result = {
            "prediction": float(prediction_value),
            "diabetes_probability": float(prediction_value),
            "has_diabetes": bool(prediction_value > 0.5),
            "prediction_time": prediction_time
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)
