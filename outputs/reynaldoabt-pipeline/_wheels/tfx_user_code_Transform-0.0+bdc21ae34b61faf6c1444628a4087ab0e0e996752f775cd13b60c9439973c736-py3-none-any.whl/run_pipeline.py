"""Main runner for diabetes prediction pipeline."""

import os
from absl import app
from tfx.orchestration.beam.beam_dag_runner import BeamDagRunner

from reynaldoabt_pipeline.pipeline import create_pipeline
from reynaldoabt_pipeline.configs import (
    PIPELINE_NAME,
    PIPELINE_ROOT,
    DATA_ROOT,
    TRANSFORM_MODULE_FILE,
    TRAINER_MODULE_FILE,
    SERVING_MODEL_DIR,
    METADATA_PATH
)

def run():
    """Runs the diabetes prediction pipeline."""
    
    # Make sure output directories exist
    os.makedirs(PIPELINE_ROOT, exist_ok=True)
    os.makedirs(METADATA_PATH, exist_ok=True)
    os.makedirs(SERVING_MODEL_DIR, exist_ok=True)
    
    # Create and run the pipeline
    BeamDagRunner().run(
        create_pipeline(
            pipeline_name=PIPELINE_NAME,
            pipeline_root=PIPELINE_ROOT,
            data_root=DATA_ROOT,
            transform_module_file=TRANSFORM_MODULE_FILE,
            trainer_module_file=TRAINER_MODULE_FILE,
            serving_model_dir=SERVING_MODEL_DIR,
            metadata_path=METADATA_PATH,
        )
    )

def main(argv):
    run()

if __name__ == '__main__':
    app.run(main)
