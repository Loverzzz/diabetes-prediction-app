
from eval_config import eval_config

def get_eval_config():
    return eval_config
