
import tensorflow_model_analysis as tfma
from tensorflow_model_analysis.metrics.post_export_metrics.metric_keys import AUCMetricKey

# Definisikan metrik evaluasi
metrics_specs = [
    tfma.MetricsSpec(
        metrics=[
            tfma.MetricConfig(class_name='AUC'),
            tfma.MetricConfig(class_name='Precision'),
            tfma.MetricConfig(class_name='Recall'),
            tfma.MetricConfig(class_name='BinaryAccuracy', threshold=0.5),
        ]
    )
]

# Definisikan slicing untuk analisis
slicing_specs = [
    tfma.SlicingSpec(),  # Evaluasi keseluruhan
    tfma.SlicingSpec(feature_keys=['gender']),  # Evaluasi per gender
    tfma.SlicingSpec(feature_keys=['smoking_history']),  # Evaluasi per riwayat merokok
]

# Buat konfigurasi evaluasi
eval_config = tfma.EvalConfig(
    model_specs=[tfma.ModelSpec(label_key='diabetes')],
    metrics_specs=metrics_specs,
    slicing_specs=slicing_specs
)

# Definisikan threshold untuk blessing
binary_classification_threshold = tfma.MetricThreshold(
    value_threshold=tfma.GenericValueThreshold(
        lower_bound={'value': 0.7},
        upper_bound={'value': 1.0}
    ),
    # Tentukan metrik yang digunakan untuk blessing
    metric_key=AUCMetricKey.AUC
)

# Buat konfigurasi blessing
metrics_thresholds = {
    AUCMetricKey.AUC: binary_classification_threshold
}
